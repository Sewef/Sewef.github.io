**Clock**
Sewef, 2021

*About the displayed print*
Printed in grey Creality PLA, painted with metal-aspect paint spray.
Black PLA may be a better choise , I didn't have it at this time.
The dial is glued on the wood using cartridge glue ; it worked better than SuperGlue in this situation.

*Informations*
Full size : 60cm diameter

*Printing*
- All part can be printed on a 20x20cm bed
- PLA friendly
- Average time : 1h average for each piece, so 12h full print
- 40% infill

*Assembly*
On a flat surface, glue with SuperGlue or equivalent.
Paint after gluing if you want.
It can bend if it doesn't lay on a flat surface, so don't store it upright.

*Reddit link*
https://www.reddit.com/r/functionalprint/comments/o67616/